<?php
$a=$_GET['nome'];
$b=$_GET['apelido'];

echo "ola ", $a, " ", $b;
?>