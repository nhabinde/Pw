<?php

function contarLetras($palavra, $letra){
         $palavra_len = strlen($palavra) -1;
         $count = 0;


         for($x = 0; $x <= $word_len; $x++){
               if($word[$x] == $letra){
                        $count++;
               }
         }

         echo "A palava".$letra." ocorre ".$count." vezes";
}

?>