<?php
$a=$_GET['valor'];
if( $a== 1){
    echo "Janeiro";
  } else
  if($a == 2){
    echo "Fevereiro";
  }else
  if($a == 3){
    echo "Março";
  }else
  if($a == 4){
    echo "Abril";
  }else
  if($a == 5){
    echo "Maio";
  }else
  if($a == 6){
    echo "Junho";
  }else
  if($a == 7){
    echo "julho";
  }else
  if($a == 8){
    echo "agosto";
  }else
  if($a == 9){
    echo "Setembro";
  }else
  if($a == 10){
    echo "Outubro";
  }else
  if($a == 11){
    echo "Novembro";
  }else
  if($a == 12){
    echo "Dezembro";
  }else{
    echo "numer do mes invalido";
  }
?>