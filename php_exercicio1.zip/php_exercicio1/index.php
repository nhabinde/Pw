<?php
$a=$_GET['valor'];
$b=$_GET['valor1'];

echo "sum : ", $a+$b;
?>