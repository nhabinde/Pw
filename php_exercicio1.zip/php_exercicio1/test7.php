<?php
// validacao/ verificacao do campo se existe ou nao
if(!isset($_POST['nome']) || !isset($_POST['apelido']) || !isset($_POST['idade'])) {
    die('erro - nao existem os campos necessarios.');
}

// verificar se todos os campos estao preenchidos


if(!empty($_POST['nome'])){
    die('erro - o nome deve ser preenchida...');
}

if(!empty($_POST['apelido'])){
    die('erro - o apelido deve ser preenchida...');
}

if(!empty($_POST['idade'])){
    die('erro - a idade deve ser preenchida...');
}

$a=$_POST['nome'];
$b=$_POST['apelido'];
$c=$_POST['idade'];
 echo"Dados submetidos com sucesso";

echo "nome: ", $a;
echo "apelido: ", $b;
echo "idade: ", $c;
?>