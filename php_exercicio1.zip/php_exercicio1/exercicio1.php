<?php
// escrever uma funcao que retorna a data numa determinada forma 13/Março/2017

    echo date('d/M/Y');
?>